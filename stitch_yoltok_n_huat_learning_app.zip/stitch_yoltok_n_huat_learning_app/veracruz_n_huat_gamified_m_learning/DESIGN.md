---
name: Veracruz Náhuat Gamified M-Learning
colors:
  surface: '#f9f9ff'
  surface-dim: '#cfdaf2'
  surface-bright: '#f9f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f0f3ff'
  surface-container: '#e7eeff'
  surface-container-high: '#dee8ff'
  surface-container-highest: '#d8e3fb'
  on-surface: '#111c2d'
  on-surface-variant: '#3c4a42'
  inverse-surface: '#263143'
  inverse-on-surface: '#ecf1ff'
  outline: '#6c7a71'
  outline-variant: '#bbcabf'
  surface-tint: '#006c49'
  primary: '#006c49'
  on-primary: '#ffffff'
  primary-container: '#10b981'
  on-primary-container: '#00422b'
  inverse-primary: '#4edea3'
  secondary: '#006591'
  on-secondary: '#ffffff'
  secondary-container: '#39b8fd'
  on-secondary-container: '#004666'
  tertiary: '#855300'
  on-tertiary: '#ffffff'
  tertiary-container: '#e29100'
  on-tertiary-container: '#523200'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#6ffbbe'
  primary-fixed-dim: '#4edea3'
  on-primary-fixed: '#002113'
  on-primary-fixed-variant: '#005236'
  secondary-fixed: '#c9e6ff'
  secondary-fixed-dim: '#89ceff'
  on-secondary-fixed: '#001e2f'
  on-secondary-fixed-variant: '#004c6e'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb95f'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#f9f9ff'
  on-background: '#111c2d'
  surface-variant: '#d8e3fb'
typography:
  headline-xl:
    fontFamily: Nunito Sans
    fontSize: 36px
    fontWeight: '800'
    lineHeight: 44px
  headline-xl-mobile:
    fontFamily: Nunito Sans
    fontSize: 28px
    fontWeight: '800'
    lineHeight: 34px
  headline-lg:
    fontFamily: Nunito Sans
    fontSize: 28px
    fontWeight: '800'
    lineHeight: 36px
  headline-lg-mobile:
    fontFamily: Nunito Sans
    fontSize: 22px
    fontWeight: '800'
    lineHeight: 28px
  headline-md:
    fontFamily: Nunito Sans
    fontSize: 20px
    fontWeight: '700'
    lineHeight: 26px
  title-lg:
    fontFamily: Nunito Sans
    fontSize: 18px
    fontWeight: '700'
    lineHeight: 24px
  title-md:
    fontFamily: Nunito Sans
    fontSize: 16px
    fontWeight: '700'
    lineHeight: 22px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '500'
    lineHeight: 26px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 15px
    fontWeight: '500'
    lineHeight: 22px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
  label-lg:
    fontFamily: Nunito Sans
    fontSize: 15px
    fontWeight: '800'
    lineHeight: 20px
    letterSpacing: 0.5px
  label-md:
    fontFamily: Nunito Sans
    fontSize: 13px
    fontWeight: '800'
    lineHeight: 18px
    letterSpacing: 0.5px
  label-sm:
    fontFamily: Nunito Sans
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.4px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-sm: 0.75rem
  margin: 1rem
  margin-tablet: 2rem
  margin-desktop: 3rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style
This design system embraces a **Tactile Playful / Gamified EdTech** aesthetic optimized for mobile language acquisition. Drawing direct inspiration from modern microlearning interfaces, the visual philosophy translates indigenous linguistic heritage into a vibrant, friendly, and tactile playground.

- **Brand Personality**: Welcoming, encouraging, energetic, and culturally respectful. The atmosphere eliminates the anxiety of learning an endangered indigenous language (Náhuat of Southern Veracruz) by framing each interaction as an achievable bite-sized quest.
- **Target Audience**: Mobile-first learners, diaspora youth, language revitalizers, and autonomous students seeking accessible, daily engagement.
- **Emotional Response**: Immediate accomplishment, tactile delight, clarity, and continuous motivation through tangible progress feedback.
- **Visual Stance**: High-clarity tactile skeuomorphism combined with crisp modern vector geometry. Prominent 3D-extruded buttons ("chunky" pressable surfaces with shaded bottom lips), high-contrast borders, crisp cards, and buoyant rounded silhouettes make every interactive element feel physically depressible.

## Colors
The color hierarchy pairs hyper-clean base neutrals with vivid semantic gamification accents.

### Core Roles
- **Primary (`#10B981` Emerald Jade)**: Represents primary validation, "Check", "Continue", and correct answers.
  - *Bottom Lip Accent*: `#059669` (Darker Jade for the 4px physical bottom lip).
  - *Light Tint*: `#D1FAE5` (Success surface / matching background).
- **Secondary (`#0EA5E9` Sky Blue)**: Designated for active interactive selection, audio playback, phoneme cards, and listening exercises.
  - *Bottom Lip Accent*: `#0284C7` (Deep Sky Blue bottom lip).
  - *Light Tint*: `#E0F2FE` (Selected card fill).
- **Tertiary (`#F59E0B` Amber Gold)**: Reserved exclusively for streaks, heart replenishment, gems/XP counters, and motivational rewards.
  - *Bottom Lip Accent*: `#D97706` (Amber Ochre bottom lip).
  - *Light Tint*: `#FEF3C7` (Achievement badges and streak banners).
- **Neutral Surface & Outlines**:
  - Background Canvas: `#FFFFFF` (Pure White) and `#F8FAFC` (Ice-Gray for stage containers and app bar scaffolds).
  - Structural Outlines: `#E2E8F0` (Default 2px structural card and surface stroke).
  - Shaded Outline Base: `#CBD5E1` (Inactive/neutral extruded button lips).
- **Typography & Icons (`#1E293B` Dark Slate)**: Provides crisp, high-legibility contrast across light backgrounds. Subdued text uses `#64748B` (Muted Slate).
- **Feedback Alerts**:
  - Error Red: `#EF4444` (Bottom lip: `#DC2626`, surface tint: `#FEE2E2`).

## Typography
The typographic architecture blends the organic, friendly geometry of **Nunito Sans** for all display headlines, milestones, and punchy buttons with the readability and balanced proportions of **Plus Jakarta Sans** for body copy and Náhuat orthography.

- **Headlines & Callouts**: Heavy weights (`800` and `700`) provide a spirited, encouraging tone. Characterized by soft terminals that harmonize with the rounded corner radii of UI modules.
- **Náhuat Diacritics & Pronunciation**: Southern Veracruz Náhuat vocabulary requires distinct phonetic reading (macrons, saltillos, and glottal stops). Plus Jakarta Sans ensures clear, non-collapsing accentuation on glyphs such as *ā, ē, ī, ō*.
- **Button Labels**: Rendered in uppercase or title-case Nunito Sans (`label-lg`) with slight tracking (`0.5px`) to simulate embossed physical labels.

## Layout & Spacing
The layout centers on a mobile-first fluid container with a rigid 4px/8px incremental rhythm designed for single-hand touch ergonomics.

- **Mobile Viewport Structure**: Single-column vertical stream. The maximum interactive canvas width is restricted to `480px` on wider screens to maintain focused, game-like pacing.
- **Margins & Safe Zones**:
  - `margin`: 16px (`1rem`) on mobile edge gutters, ensuring generous thumb clearance.
  - Sticky bottom sheets and persistent evaluation docks carry an internal horizontal padding of `1rem` and top/bottom padding of `1.25rem`.
- **Vertical Rhythm**:
  - `space-xs` (4px): Used for the physical button lip extrusion offset.
  - `space-sm` (8px): Gaps between small chips, badges, and icon-to-label inline pairings.
  - `space-md` (16px): Standard gap between multiple-choice word bank options and vocabulary translation cards.
  - `space-lg` (24px): Separation between prompt instructions, audio triggers, and exercise working areas.
  - `space-xl` (32px): Lesson transition blocks and module completion checkpoints.

## Elevation & Depth
Depth in this system avoids blurry drop shadows in favor of **Crisp Geometric Extrusion (Tactile 3D Lips)**. 

- **The 4px Bottom Lip**: Physical push-buttons and clickable tiles feature a solid 4px base border (or solid drop-box effect) along their bottom edge in a 20% darker shade of the element's base color. 
  - *Resting State*: Bottom lip visible (`box-shadow: 0 4px 0 0 [Darker Shade]`).
  - *Hover/Focus*: Retains 4px lip with a subtle color lift.
  - *Active / Pressed State*: The element shifts down `4px` (`transform: translateY(4px)`) while the bottom lip reduces to `0px` (`box-shadow: 0 0 0 0 [Darker Shade]`), delivering immediate mechanical satisfaction.
- **Card Framing**: Secondary surfaces, inactive choices, and word tiles sit on a solid `2px` border (`#E2E8F0`) with a matching `2px` or `3px` neutral resting bottom lip (`#CBD5E1`).
- **Overlays & Dialog Sheets**: Bottom-pinned completion drawers use a flat neutral backdrop scrim (`rgba(15, 23, 42, 0.4)`) with no blur, prioritizing sharp contrast and immediate reaction speed.

## Shapes
The shape language relies heavily on friendly, welcoming curves that reinforce an approachable learning posture.

- **Base Radius (`16px` / `1rem`)**: Applied universally to interactive cards, vocabulary select tiles, modal dialogs, and progress card wrappers.
- **Pill Shapes (`9999px`)**: Reserved for primary action push buttons, sound trigger circular bubbles, streak counter capsules, and lesson track progress bars.
- **Border Weights**: Consistent `2px` continuous solid perimeter borders across all cards, tiles, and input containers to ensure visual stability against both white and ice-gray backgrounds.

## Components

### Buttons
- **Primary Action (Check / Continue)**: 
  - Pill-shaped (`rounded-full`), height `52px`, background `#10B981`, text `#FFFFFF`, bottom lip `4px solid #059669`.
  - Active press: `translateY(4px)`, bottom lip compresses to `0px`.
- **Secondary / Audio Playback**:
  - Circular (`56px × 56px`) or pill-shaped, background `#0EA5E9`, text `#FFFFFF`, bottom lip `4px solid #0284C7`. Houses a bold speaker icon.
- **Inactive / Disabled**:
  - Background `#E2E8F0`, text `#94A3B8`, bottom lip `4px solid #CBD5E1`. Disables transformation.

### Vocabulary Selection Cards & Tokens
- **Multiple Choice Word Tile**:
  - Background `#FFFFFF`, 16px radius, `2px` perimeter border `#E2E8F0`, bottom lip `3px solid #E2E8F0`, padding `16px 20px`.
  - Content: Bold Náhuat word (`title-lg`, `#1E293B`), optional Spanish/English subtle translation (`body-sm`, `#64748B`).
  - *Selected State*: Background `#F0F9FF`, perimeter border `#0EA5E9`, bottom lip `3px solid #0284C7`, text `#0369A1`.

### Word Bank Chips (Drag & Tap)
- Compact pill-shaped modules. Background `#FFFFFF`, border `2px solid #E2E8F0`, bottom lip `3px solid #E2E8F0`, padding `8px 16px`.
- *Empty Slot / Target Placeholder*: Dashed `2px` border `#CBD5E1`, background `#F8FAFC`, no bottom lip.

### Gamification Meters & App Bar
- **Streak & XP Counter**:
  - Compact capsules (`rounded-full`), background `#FFFBEB`, border `1.5px solid #FDE68A`, displaying amber flame (`#F59E0B`) + streak number.
- **Lesson Progress Bar**:
  - Full-width `16px` high track, background `#E2E8F0`, rounded-full.
  - Fill indicator: `#10B981` with an inner top gloss highlight (`rgba(255, 255, 255, 0.35)`) and smooth animated width expansion.

### Feedback Bottom Sheets (Evaluation Drawers)
- Slide-up panels pinned to the viewport bottom:
  - **Success / Correct**: Background `#ECFDF5`, top border `2px solid #A7F3D0`. Includes a green circular check icon, celebration copy ("¡Kwali!" / "Well done!"), and primary Emerald Jade continue button.
  - **Correction / Incorrect**: Background `#FEF2F2`, top border `2px solid #FECACA`. Displays correct orthography with phoneme breakdown and red continue button.

### Form Inputs & Text Prompts
- Large tactile text entry fields. Background `#F8FAFC`, `16px` border-radius, `2px solid #CBD5E1`, focus state turns border to `#0EA5E9` with an inner white fill.